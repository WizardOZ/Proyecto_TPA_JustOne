public class Usuario {
    private String nombre;
    private String email;
    private String contraseña;

    public void iniciarSesion() {

    }

    public void cerrarSesion() {
    }

    public void registro() {

    }
}

