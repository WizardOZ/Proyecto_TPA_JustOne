import java.util.Date;

public class HistorialCompra {
    private Date fecha;
    private int cantidad;
    private String tipo;

    public void generarFactura() {

    }
}
