package Juego;

public class Main {
    public static void main(String[] args) {
        // Crear y mostrar la ventana de login
        new LoginFrame();
    }
}
