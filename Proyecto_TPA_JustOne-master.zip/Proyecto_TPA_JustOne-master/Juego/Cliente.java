public class Cliente extends Usuario {

    public void comprarProducto() {

    }

    public void verHistorialCompras() {

    }

    public void consultarDatos() {

    }
}
