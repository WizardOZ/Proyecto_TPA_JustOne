public class Administrador extends Usuario {

    public void gestionarProducto() {

    }

    public void gestionarPrecio() {

    }

    public void realizarVenta() {
    }

    public void consultarDatos() {
    }
}
